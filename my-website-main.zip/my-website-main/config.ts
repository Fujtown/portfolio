const config = {
  // Other development-specific configuration options
};

export default config;
